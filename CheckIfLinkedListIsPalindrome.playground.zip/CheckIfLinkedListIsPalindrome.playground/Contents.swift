//Determine if a linked list is a palidrome
public class ListNode {
  public var val: Int
  public var next: ListNode?
  public init(_ val: Int) {
      self.val = val
      self.next = nil
  }
}

func isPalindrome(_ head: ListNode?) -> Bool {
    
    guard head != nil else {return true}
    
    var slow = head; var fast = head?.next
    
    while fast != nil && fast?.next?.next != nil{
        fast = fast?.next?.next
        slow = slow?.next
    }
    fast = head
    
    slow = reverseSLL(slow!)

    while slow != nil && fast != nil{
        guard slow?.val == fast?.val else {return false}
        slow = slow?.next
        fast = fast?.next
    }

    return true
}

func reverseSLL(_ head: ListNode) -> ListNode{
    var prev:ListNode?
    var x = head
    while let next = x.next {
        x.next = prev
        prev = x
        x = next
    }
    x.next = prev
    
    return x
}

//1221
let palindromeOne = ListNode(1)
let palindromeTwo = ListNode(2)
let palindromeThree = ListNode(2)
let palindromeFour = ListNode(1)

palindromeOne.next = palindromeTwo
palindromeTwo.next = palindromeThree
palindromeThree.next = palindromeFour

//2334
let notPalindromeOne = ListNode(2)
let notPalindromeTwo = ListNode(3)
let notPalindromeThree = ListNode(3)
let notPalindromeFour = ListNode(4)

notPalindromeOne.next = notPalindromeTwo
notPalindromeTwo.next = notPalindromeThree
notPalindromeThree.next = notPalindromeFour

isPalindrome(palindromeOne)
isPalindrome(notPalindromeOne)
